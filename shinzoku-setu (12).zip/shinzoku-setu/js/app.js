/* =========================================================================
   Shinzoku Setu — app shell: shared state, pages, step flow, language, helpers
   ========================================================================= */
(function () {
  /* ---------- Helpers used by all pages ---------- */
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const t = (ja, en) => `<span class="ja">${ja}</span><span class="en">${en}</span>`;
  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));

  const store = {
    get(k, fallback) { try { const v = localStorage.getItem("indiaDesk." + k); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; } },
    set(k, v) { try { localStorage.setItem("indiaDesk." + k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } },
  };

  /* Source chip: shows the regulation and when the team last checked it. */
  function source(key, lastChecked) {
    const s = ID.SOURCES[key];
    if (!s) return "";
    const checked = lastChecked ? `<span class="muted">· ${t("確認日", "checked")} ${esc(lastChecked)}</span>` : "";
    return `<span class="source${lastChecked ? "" : " unverified"}" title="${esc(s.authority)}">${esc(s.name)} ${checked}${lastChecked ? "" : " · " + t("未確認", "not verified")}</span>`;
  }
  const money = (n) => "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  /* A photo slot: shows images/<file> if it exists, otherwise a labelled placeholder. */
  const photo = (file, ja, en, cls) => `<div class="photo ${cls || ""}"><span class="photo-label">${t("写真", "Photo")}: ${t(ja, en)}</span><img src="images/${file}" alt="" onerror="this.remove()" /></div>`;

  /* ---------- Tooltip ---------- */
  const tip = () => $("#tooltip");
  function showTip(html, ev) { const el = tip(); el.innerHTML = html; el.hidden = false; moveTip(ev); }
  function moveTip(ev) {
    const el = tip(); if (el.hidden) return;
    el.style.left = Math.min(ev.clientX + 14, window.innerWidth - el.offsetWidth - 8) + "px";
    el.style.top = Math.min(ev.clientY + 14, window.innerHeight - el.offsetHeight - 8) + "px";
  }
  const hideTip = () => { tip().hidden = true; };

  /* ---------- Shared state ---------- */
  const DEMO = { category: "food", name: "和風だしせんべい (Dashi Rice Crackers)", price: 240, mfg: "2026/10/01", exp: "2027/04/01" };
  const DEMO_LABEL = "原材料名：うるち米（国産）、植物油脂、しょうゆ、砂糖、かつおぶし粉末、食塩、こんぶエキス\n栄養成分表示（1袋40g当たり）エネルギー 196kcal たんぱく質 2.9g 脂質 8.6g 炭水化物 26.8g 食塩相当量 0.9g";

  ID.state = {
    product: store.get("product", { category: "food", name: "", price: "", mfg: "", exp: "" }),
    label: { text: "", image: null, present: [], result: null, nutrition: null, kids: null, diet: null, heat: null },
    shelf: store.get("shelf", { dispatch: "", transit: 26, clearance: 6, cos: {}, route: { jpPort: "tyo", inPort: "nsa", scenario: "typical" } }),
    price: store.get("price", { rate: 0.56, freight: 20, dutyPct: 30, cepa: false, cepaPct: 0, gstPct: 18, clearance: 0, mImp: 20, mDist: 10, mRet: 25 }),
    map: { data: null, weights: null, selected: null },
    partners: store.get("partners", []),
    roadmap: store.get("roadmap", {}),
    testLog: store.get("testLog", []),
    visited: store.get("visited", {}),
  };
  ID.save = (k) => store.set(k, ID.state[k]);

  /* Runs the label check and the checks that depend on it. */
  ID.runLabel = function (text) {
    const s = ID.state.label, cat = ID.state.product.category;
    s.text = text;
    s.result = ID.auditLabel(text, cat, ID.DICTIONARY, s.present);
    s.nutrition = cat === "food" ? ID.parseNutrition(text) : null;
    s.kids = cat === "food" ? ID.kidsCheck(text, s.nutrition && s.nutrition.found ? s.nutrition : null) : null;
    s.diet = cat === "food" ? ID.dietCheck(s.result) : null;
    s.heat = ID.heatCheck(text, ID.state.product.name, cat);
  };

  /* ---------- The step flow ---------- */
  ID.STEPS = [
    { id: "product", ja: "製品", en: "Product" },
    { id: "label", ja: "ラベル", en: "Label" },
    { id: "shelf", ja: "賞味期限", en: "Shelf life" },
    { id: "price", ja: "価格", en: "Price" },
    { id: "map", ja: "州", en: "Market" },
    { id: "partner", ja: "パートナー", en: "Partner" },
    { id: "negotiate", ja: "交渉準備", en: "Negotiation" },
  ];
  function stepDone(id) {
    const st = ID.state, p = st.product;
    switch (id) {
      case "product": return !!(p.name && ID.parseDate(p.mfg) && ID.parseDate(p.exp));
      case "label": return !!st.label.result;
      case "shelf": return p.category === "food" ? !!(st.shelf.dispatch && ID.parseDate(st.shelf.dispatch)) : Object.values(st.shelf.cos || {}).some(Boolean);
      case "price": return !!p.price;
      case "partner": return st.partners.length > 0;
      default: return !!st.visited[id];
    }
  }

  function stepper(current) {
    const idx = ID.STEPS.findIndex((s) => s.id === current);
    return `<nav class="stepper" aria-label="Steps"><div class="wrap stepper-row">${ID.STEPS.map((s, i) => {
      const done = stepDone(s.id), now = i === idx;
      return `<a href="#${s.id}" class="step ${now ? "now" : ""} ${done ? "done" : ""}" ${now ? 'aria-current="step"' : ""}>
        <span class="bar"></span><span class="row nowrap"><span class="dot">${done && !now ? "✓" : i + 1}</span><span class="lbl">${t(s.ja, s.en)}</span></span></a>`;
    }).join("")}</div></nav>`;
  }

  function stepNav(current) {
    const i = ID.STEPS.findIndex((s) => s.id === current);
    const prev = ID.STEPS[i - 1], next = ID.STEPS[i + 1];
    return `<div class="stepnav wrap">
      ${prev ? `<a class="btn ghost lg" href="#${prev.id}">← ${t("戻る", "Back")}: ${t(prev.ja, prev.en)}</a>` : `<a class="btn ghost lg" href="#home">← ${t("ホーム", "Home")}</a>`}
      ${next ? `<a class="btn primary lg" href="#${next.id}">${t("次へ", "Next")}: ${t(next.ja, next.en)} →</a>` : `<a class="btn primary lg" href="#report">${t("レポートを見る", "View report")} →</a>`}
    </div>`;
  }

  function productChip() {
    const p = ID.state.product;
    if (!p.name) return "";
    return `<div class="wrap chipline"><span class="chip">${esc(p.name)} · ${p.category === "food" ? t("加工食品", "Packaged food") : t("化粧品", "Cosmetics")}${p.price ? ` · ¥${esc(p.price)}` : ""}</span><a href="#product" class="small">${t("変更", "Edit")}</a></div>`;
  }

  /* ---------- Pages ---------- */
  ID.views = {};
  function render() {
    const name = (location.hash || "#home").slice(1);
    const view = ID.views[name] ? name : "home";
    const isStep = ID.STEPS.some((s) => s.id === view);
    if (isStep && !ID.state.visited[view]) { ID.state.visited[view] = true; ID.save("visited"); }
    $$(".mainnav a").forEach((a) => a.classList.toggle("active", a.dataset.nav === (isStep ? "steps" : view)));
    const main = $("#view");
    hideTip();
    if (isStep) {
      main.innerHTML = `${stepper(view)}${productChip()}<div class="wrap page" id="page"></div>${stepNav(view)}`;
      ID.views[view].render($("#page"));
    } else if (view === "home") {
      main.innerHTML = `<div id="page"></div>`;
      ID.views.home.render($("#page"));
    } else {
      main.innerHTML = `<div class="wrap page" id="page"></div>`;
      ID.views[view].render($("#page"));
    }
    main.focus({ preventScroll: true });
  }
  /* Re-render after a change, keeping the scroll position. */
  ID.rerender = () => { const y = window.scrollY; render(); window.scrollTo(0, y); };
  ID.go = (name) => { if (location.hash === "#" + name) render(); else location.hash = name; window.scrollTo(0, 0); };

  /* ---------- Language ---------- */
  function setLang(lang) {
    document.body.classList.remove("lang-both", "lang-ja", "lang-en");
    document.body.classList.add("lang-" + lang);
    document.documentElement.lang = lang === "en" ? "en" : "ja";
    $$(".seg [data-lang]").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
    store.set("lang", lang);
  }

  /* ---------- Demo ---------- */
  function loadDemo() {
    Object.assign(ID.state.product, DEMO);
    ID.save("product");
    ID.state.label = { text: "", image: null, present: [], result: null, nutrition: null, kids: null, diet: null, heat: null };
    ID.runLabel(DEMO_LABEL);
    ID.state.shelf.dispatch = "2026/10/20";
    ID.state.nego = { cost: 190, minProfit: 15, extra: 5, partner: 0, out: {} }; store.set("nego", ID.state.nego);
    ID.save("shelf");
    ID.go("label");
  }

  /* ---------- Settings ---------- */
  function bindSettings() {
    const dlg = $("#settings");
    $("#btn-settings").addEventListener("click", () => {
      $("#s-key").value = ID.gemini.key();
      $("#s-model").value = ID.gemini.model();
      $("#s-backup").value = ID.gemini.backup();
      dlg.showModal();
    });
    dlg.addEventListener("close", () => {
      if (dlg.returnValue === "save") { ID.gemini.save($("#s-key").value.trim(), $("#s-model").value.trim(), $("#s-backup").value.trim()); ID.rerender(); }
    });
  }

  ID.start = function () {
    setLang(store.get("lang", "both"));
    bindSettings();
    $$(".seg [data-lang]").forEach((b) => b.addEventListener("click", () => setLang(b.dataset.lang)));
    $("#btn-demo").addEventListener("click", loadDemo);
    window.addEventListener("hashchange", () => { render(); window.scrollTo(0, 0); });
    document.addEventListener("mousemove", moveTip);
    if (ID.chat) ID.chat.init();
    render();
  };

  ID.loadDemo = loadDemo;
  Object.assign(ID.ui = {}, { esc, t, $, $$, source, money, showTip, hideTip, store, photo });
})();
