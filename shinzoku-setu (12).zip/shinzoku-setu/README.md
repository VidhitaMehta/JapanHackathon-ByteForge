# Shinzoku Setu

A virtual India export team for Japanese consumer-goods SMEs. Built for the Thapar Japan Hackathon (JETRO-PS-01).

**Principle: fixed rules decide, AI assists.** Every compliance verdict comes from rules written in `js/data/`. AI (Gemini) is used only to read label photos, translate, and draft messages.

## Run it

No installs and no build step: it's plain HTML, CSS and JavaScript.

**In VS Code (recommended)**
1. Open the `india-desk` folder in VS Code (File → Open Folder).
2. Install the **Live Server** extension (VS Code will suggest it).
3. Right-click `index.html` → **Open with Live Server**.

**Without VS Code:** double-click `index.html` to open it in Chrome or Edge.

An internet connection is needed for the fonts and for Gemini; everything else works offline.

## Pages

**Home** (photo banner, facts, how it works, tools) and a **7-step flow** with a progress bar and Back / Next buttons:

| Step | Page | What it does | Needs AI? |
|---|---|---|---|
| 1 | Product | Enter category, name, price and dates once | No |
| 2 | Label Check | Ingredients (veg/non-veg, never guessing), **nutrition compared with India's requirements**, **children's guidance check**, missing label items, sticker text | Only for reading photos |
| 3 | Shelf Life / Registration | Food: 60% rule, latest safe dispatch. Cosmetics: CDSCO pre-filing checklist | No |
| 4 | Price | Landed cost and shelf price, CEPA toggle | No |
| 5 | Market (Launch Map) | **Income (MoSPI urban MPCE) + Google Trends**, plus **state rules** (beef restrictions, alcohol prohibition) from the label result | No |
| 6 | Partner | Compare importers; **due-diligence checklist with a checks-done score**; **guide to working with an Indian partner**; send a product brief, email or WhatsApp message (no software needed by the importer) | No |
| 7 | Plan | Steps from now to first sale | No |

Also: **Assistant** (💬 button, answers using the app's results; needs a key), **Test Log**, **Report** and **Product brief** (both save as PDF through the print dialog).

**Photos:** put them in `images/` (see `images/README.md`). Until then, labelled placeholders show.

## Folder structure

```
index.html                 the page
css/style.css              all styling (change --accent to rebrand)
js/data/rules.js           FSSAI and CDSCO rules, each with its source and "last checked" date
js/data/dictionary.js      Japanese ingredient dictionary (add entries here)
js/data/states.js          state data (real Google Trends so far) and tile-map layout
js/core/engine.js          all calculations (pure functions, tested)
js/core/gemini.js          Gemini calls (OCR, translation, drafting only)
js/app.js                  navigation, product bar, language toggle
js/modules/*.js            one file per page (home, product, label, shelf, price, map, partner, negotiate, report, brief, chat, testlog)
images/                    your photos (see images/README.md)
tests/                     automated tests and map test files
```

## Tests

- **In a browser:** open `tests/index.html` (74 tests).
- **In a terminal:** `node tests/run-tests.js` (needs Node.js).

The tests cover the veg/non-veg rule, the matcher fixes (牛乳 is milk not beef, 水 is not mercury, 昆布だし is not fish stock, 乳化剤 needs review), the Matcha Cookies shelf-life and price examples, and the map scoring. To check the map by hand, upload `tests/data/test1.csv` (expect 100 / 50 / 0) and `tests/data/test2.csv` (expect 30 / 20).

## Before the demo

Step-by-step instructions are in `GUIDE-testing-and-data.md`.


1. **Add the remaining state data** (spending, internet use, Japanese business presence). Search interest from Google Trends is already built in. In the app: Launch Map → "Download data as CSV", fill the blank columns, then "Upload CSV". Or edit `js/data/states.js` directly.
2. **Check every rule** in `js/data/rules.js` against the official source and update `lastChecked`. Licence number formats are marked "not verified".
3. **Test on real labels:** run about 10 real Japanese products through Label Check, save each to the Test Log, mark results, and use the accuracy figure in your pitch.

## Changing things

- **Add an ingredient:** add a line to `js/data/dictionary.js`. The matcher uses the longest matching keyword, so a specific term (牛乳) beats a short one (牛).
- **Change a rule or threshold:** edit `js/data/rules.js`.
- **Change colours:** edit the variables at the top of `css/style.css`.

*Guidance only. Confirm with your importer or a regulatory adviser before exporting.*

## Map credit
Launch Map state outlines: DataMeet India community, "States/Admin2" (github.com/datameet/maps), CC BY 4.0, simplified.
